#include <bits/stdc++.h>
using namespace std;
#define pb push_back
typedef long long ll;
const int MOD=10000121;
int A[MOD];
int parse_constant(string s)
{
	int w=atoi(s.c_str());
	if(w<0||w>=MOD) throw "invalid constant";
	static char buf[55];
	sprintf(buf,"%d",w);
	if(s!=buf) throw "invalid constant";
	return w;
}
int parse_param(string s,int dep=2)
{
	if(!s.size()) throw "invalid param";
	if(s[0]=='A')
	{
		if(s.size()<4||dep==0
		||s[1]!='['||s[s.size()-1]!=']') throw "invalid param";
		return A[parse_param(s.substr(2,s.size()-3),dep-1)];
	}
	else return parse_constant(s);
}
string parse_label(string s)
{
	if(s.size()<=0||s.size()>15)
		throw "invalid label string";
	for(auto c:s) if(!islower(c))
		throw "invalid label string";
	return s;
}
vector<string> split(string s,char d=' ')
{
	string u;
	vector<string> v;
	for(auto c:s)
	{
		if(c==d)
		{
			if(u.size()) v.pb(u),u.clear();
		}
		else u.pb(c);
	}
	if(u.size()) v.pb(u);
	return v;
}
ll qp(ll a,ll b)
{
	ll x=1; a%=MOD;
	while(b)
	{
		if(b&1) x=x*a%MOD;
		a=a*a%MOD; b>>=1;
	}
	return x;
}
vector<string> ss[450000]; int sn=0;
char buf[450000];
unordered_map<string,int> jmp_table;
void pre()
{
	set<string> req;
	//first check
	for(int i=1;i<=sn;++i)
	{
		if(ss[i][0]=="mul")
		{
			if(ss[i].size()!=4) throw "wrong number of params";
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_param(ss[i][3]);
		}
		else if(ss[i][0]=="pow")
		{
			if(ss[i].size()!=4) throw "wrong number of params";
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_param(ss[i][3]);
		}
		else if(ss[i][0]=="add")
		{
			if(ss[i].size()!=4) throw "wrong number of params";
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_constant(ss[i][3]);
		}
		else if(ss[i][0]=="label")
		{
			if(ss[i].size()!=2) throw "wrong number of params";
			auto a=parse_label(ss[i][1]);
			if(jmp_table.count(a))
				throw "duplicate label "+ss[i][1];
			jmp_table[a]=i;
		}
		else if(ss[i][0]=="if")
		{
			if(ss[i].size()!=4) throw "wrong number of params";
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]);
			auto c=parse_label(ss[i][3]);
			req.insert(c);
		}
		else if(ss[i][0]=="input")
		{
			if(ss[i].size()!=2) throw "wrong number of params";
			auto a=parse_param(ss[i][1]);
		}
		else if(ss[i][0]=="output")
		{
			if(ss[i].size()!=2) throw "wrong number of params";
			auto a=parse_param(ss[i][1]);
		}
		else throw "invalid operation "+ss[i][0];
	}
	for(auto l:req)
		if(!jmp_table.count(l)) throw "missing label "+l;
}
int su=0;
void run()
{
	int i=1;
	int tot=0,lbl=0;
	while(i<=sn)
	{
		++tot;
		if(ss[i][0]=="mul")
		{
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_param(ss[i][3]);
			A[a]=b*(ll)c%MOD;
		}
		else if(ss[i][0]=="pow")
		{
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_param(ss[i][3]);
			A[a]=qp(b,c);
		}
		else if(ss[i][0]=="add")
		{
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]),
			c=parse_constant(ss[i][3]);
			A[a]=(b+c)%MOD;
		}
		else if(ss[i][0]=="label")
		{
			--tot; ++lbl;
		}
		else if(ss[i][0]=="if")
		{
			auto a=parse_param(ss[i][1]),
			b=parse_param(ss[i][2]);
			auto c=parse_label(ss[i][3]);
			if(a==b) i=jmp_table[c]-1;
		}
		else if(ss[i][0]=="input")
		{
			auto a=parse_param(ss[i][1]);
			cin>>A[a];
			if(A[a]<0||A[a]>=MOD)
				throw "input out of range";
		}
		else if(ss[i][0]=="output")
		{
			auto a=parse_param(ss[i][1]);
			cout<<a<<"\n";
		//	system("pause");
		}
		++i;
	}
	cerr<<"\n\n=================================\nYour score: "<<max(tot,lbl)<<" (code="<<tot<<" label="<<lbl<<")\nCode length: "<<su<<"\n";
}
void work(string fn)
{
	FILE*fp=fopen(fn.c_str(),"r");
	while(!feof(fp))
	{
		if(fgets(buf,419990,fp)==NULL) break;
		string u=buf;
		while(u.size()&&(u.back()=='\n'||u.back()=='\r'))
			u.pop_back();
		su+=int(u.size())+1;
		auto w=split(u);
		if(w.size()) ss[++sn]=w;
		if(su>102400) throw "code too long";
	}
	pre(); run();
}
int main(int argc,char**argv)
{
	if(argc!=2)
	{
		fprintf(stderr,"usage: simulator code.out <input.txt\n");
		return 0;
	}
	try
	{
		work(argv[1]);
	}
	catch(const char*s)
	{
		fprintf(stderr,"error occured: %s\n",s);
	}
	catch(string s)
	{
		fprintf(stderr,"error occured: %s\n",s.c_str());
	}
}
