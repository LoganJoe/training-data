#include<vector>
void findMatrix(int N);
bool isSubMatrix(std::vector<std::vector<char>> matrix);
void foundMatrix(std::vector<std::vector<char>> matrix);
